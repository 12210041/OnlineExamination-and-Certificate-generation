<?php
session_start();
unset($_SESSION["adminu"]);
session_destroy();
?>
<script>
    window.location="../pages/login.php";
</script>