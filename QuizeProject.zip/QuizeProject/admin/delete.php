<?php
include '../pages/connection.php';
$id=$_GET["id"];

$sql="delete from exam_category where id=$id";
if(mysqli_query($conn,$sql))
{
    $sql1="delete from questions where category_id=$id";
    mysqli_query($conn,$sql1);
    ?>
    <script>
        alert("category id <?php echo $id ?> is deleted");
    </script><?php
}else{
    echo "error";
}

?>
<script>
    window.location="exam_category.php";
</script>