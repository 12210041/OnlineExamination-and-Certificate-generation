<?php include 'sidebar.html';
include '../pages/connection.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Category</title>
    <style>
        table tr:nth-child(odd) {
            background: gray;
            color:yellow;
            position: sticky;
            top:0;
            }
        .row-add{
            width:85%;
            margin-left:15%;
        }
        ::-webkit-scrollbar {
         width: 10px;
}
::-webkit-scrollbar-thumb {
  background:lightblue; 
  border-radius: 10px;
}
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius: 10px;
}
        .box{
            background-color:white;
            height: 50vh;
            width:70%;
            margin-left:5%;
            margin-top:7%;
            border-radius:20px;
            box-shadow:10px 9px 10px #0dcaf0;
            overflow:scroll;
            
        }
        input,label,select{
            display:block;
            width:80%;
            margin-left:10%;
            padding:10px;
            border-radius:20px;
        }
        input:focus{
            box-shadow:4px 5px 10px green;
        }
        .top{
            height:11vh;
            position: relative;
            width: 85%;
            top:0px;
            left:15%;
        }
        .add{
            padding:10px;
            margin-left:10%;
            margin-top:5%;
        }
        table,td,th{
            border-collapse:collapse;
            border:1px solid black;
            text-align:center;
            padding:5px;
        }
        label::after{
            content:'*';
            color:red;
        }
        option:nth-child(2){
            color:red;
        }
        
    </style>
</head>
<body style="background-image:url(../img/b4.jpg)">
<div class="top bg-info">
    
</div>

   <div class="row row-add">
    <div class="col-6 box">
   
        <h3 class="d-flex justify-content-center bg-light text-success" style="padding:10px;margin-top:1%;">Select Questions Category to add question</h3>
        <div class="alert alert-success" role="alert" style="display:none">Successfully added</div>
        <div class="alert alert-primary" role="alert" style="display:none">update successfully</div>
        <div class="alert alert-warning" role="alert" style="display:none">Something went wrong!</div>
        <div class="alert alert-danger" role="alert" style="display:none">All fields are mandatory!</div>
<form action="" method="POST" onsubmit="return Validation()">
   <!-- select exam category -->
   <table width="100%">
    <tr>
            <th>cat_id</th>
            <th colspan="4">cat_id</th>
            <th>Duration</th>
            <th>Select</th>
    </tr>
        <?php
        $sql_q="select * from exam_category";
        $res2=mysqli_query($conn,$sql_q);
        while($row=mysqli_fetch_assoc($res2))
        {   ?>
            <tr>
            <td><?php echo $row["id"] ?></td>
            <td colspan="4"><?php echo $row["category"] ?></td>
            <td> <?php echo $row["duration"] ?></td>
            <td><a href="add_questions.php?id=<?php echo $row["id"];?>"><i class="fa-solid fa-hand-pointer"></i>Select</a></td>
            <tr>
             <?php
        }
        ?>
        </table>
</form>

</body>
</html>
