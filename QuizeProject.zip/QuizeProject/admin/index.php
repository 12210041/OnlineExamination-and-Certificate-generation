
<?php

include 'sidebar.html';
session_start();
$get=$_SESSION["adminu"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <style>
        .top{
            height:10vh;
            position: relative;
            width: 85%;
            top:5px;
        }
        .top-2{
            height:10vh;

            position:relative;
            width: 85%;
            margin-top:10px;
        }
        .top-2 p{
            font-size:25px;
            padding:1.5%;
        }
        .top-3{
            height:10vh;

            position:relative;
            width: 85%;
            margin-top:10px;
        }

        .body{
            position:fixed;
            left:15%;
        
        }
        .disp{
            height:73vh;
        }
    </style>
</head>
<body class="bg-light">
<div class="container-fluid body">
<div class="top bg-info">
    <p><i class="fa-regular fa-user"></i> <?php echo $get;?></p>
</div>
<div class="top-2 bg-info">
    <p>Dashboard</p>
</div>
        <div class="disp">

        </div>
    <div style="width:85%">
    <?php include '../pages/footer.html'?>
    </div>
</div>

</body>
</html>
