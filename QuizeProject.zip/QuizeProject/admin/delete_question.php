

<?php
require "../pages/connection.php";
$id=$_GET["id"];
$sql="delete from questions where q_id=$id";
if(mysqli_query($conn,$sql))
{
   ?>
<script>
    window.location="question_edit.php";
    </script>

   <?php
}else{
    echo "error";
}
?>