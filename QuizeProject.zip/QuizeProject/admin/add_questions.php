<?php include 'sidebar.html';
include '../pages/connection.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Category</title>
    <style>
        table tr:nth-child(odd) {
            background: gray;
            color:yellow;
            position: sticky;
            top:0;
            }
        .row-add{
            width:85%;
            margin-left:15%;
        }
        ::-webkit-scrollbar {
         width: 10px;
}
::-webkit-scrollbar-thumb {
  background:green; 
  border-radius: 10px;
}
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius: 10px;
}
        .box{
            background-color:white;
            height: 80vh;
            width:44%;
            margin-left:2%;
            margin-top:2%;
            border-radius:20px;
            box-shadow:10px 9px 10px #0dcaf0;
            overflow:scroll;
            
        }
        input,label,select{
            display:block;
            width:80%;
            margin-left:10%;
            padding:10px;
            border-radius:20px;
        }
        input:focus{
            box-shadow:4px 5px 10px green;
        }
        .top{
            height:11vh;
            position: relative;
            width: 85%;
            top:0px;
            left:15%;
        }
        .add{
            padding:10px;
            margin-left:10%;
            margin-top:5%;
        }
        table,td,th{
            border-collapse:collapse;
            border:1px solid black;
            text-align:center;
            padding:5px;
        }
        label::after{
            content:'*';
            color:red;
        }
        option:nth-child(2){
            color:red;
        }
        #add{
            width:30%;
            
        }
        
    </style>
</head>
<body style="background-image:url(../img/b4.jpg)">
<div class="top bg-info">
    
</div>

   <div class="row row-add">
    <div class="col-6 box">
   
        <h3 class="d-flex justify-content-center bg-light text-success" style="padding:10px;margin-top:1%;">Add New Questions</h3>
        <div class="alert alert-success" role="alert" style="display:none">Successfully added</div>
        <div class="alert alert-primary" role="alert" style="display:none">update successfully</div>
        <div class="alert alert-warning" role="alert" style="display:none">Something went wrong!</div>
        <div class="alert alert-danger" role="alert" style="display:none">All fields are mandatory!</div>
<form action="" method="POST" onsubmit="return Validation()">
   <!-- select exam category -->
    <label for="ecat">Exam Category</label>
    <select name="ecat" id="ecat">
        
        <?php
        $id=$_GET["id"];
            echo "<option value=$id>$id</option>";
        ?>
    </select>
    <!-- select exam category end -->
    <label for="ques">Add Questions</label>
    <input type="text" id="que" name="ques" placeholder="Question?">
    <label for="opt1">Option 1.</label>
    <input type="text" id="opt1" name="opt1" placeholder="">
    <label for="opt2">Option 2.</label>
    <input type="text" id="opt2" name="opt2" placeholder="">
    <label for="opt1">Option 3.</label>
    <input type="text" id="opt3" name="opt3" placeholder="">
    <label for="opt1">Option 4.</label>
    <input type="text" id="opt4" name="opt4" placeholder="">
    <label for="ans">Currect Answer</label>
    <input type="text" id="ans" name="ans" placeholder="currect answer">
    <button type="submit" id="add" name="add" class="btn btn-outline-success add">Add</button>
</form>

    </div>
    <div class="col-6 box" style="  overflow:scroll;">
    <h3 class="d-flex justify-content-center bg-light text-success" style="padding:5px;margin-top:5%;">Added Questions</h3>
    <table width="100%" cellspaci frame="box">

        <th>C_Id</th>
        <th>Q_Id</th>
        <th colspan="7">Question</th>
        <th>currect option</th>
        <th>Edit</th>
        <th>Delete</th>
        <?php 
        $sql="select * from questions where category_id=$id";
        $res=mysqli_query($conn,$sql);
        if(mysqli_num_rows($res)>0)
        {
            while($row=mysqli_fetch_assoc($res))
            {
               ?>
               <tr>
               <td><?php echo $id?></td>
               <td><?php echo $row["q_id"] ?></td>
               <td colspan="7"><?php echo $row["question"] ?></td>
               <td> <?php echo $row["ans"] ?></td>
               <td><a href="question_edit.php?id=<?php echo $row["q_id"];?>"><i class="fa-solid fa-pen"></i></a></td>
               <td><a href="delete_question.php?id=<?php echo $row["q_id"];?>"><i class="fa-solid fa-trash"></i></a></td>
               <tr>
                <?php
            }
        }
        ?>
        <script>
            let cc=<?php echo mysqli_num_rows($res)?>;
            document.querySelector('#t').value="time";
            </script>
        <?php
        ?>
    </table>
    </div>
   </div>
   <?php
//    insert data in database start
   if(isset($_POST['add']))
   {
    $sql_a1 = "INSERT INTO questions(question, opt1, opt2, opt3, opt4, ans, category_id) 
    VALUES('$_POST[ques]', '$_POST[opt1]', '$_POST[opt2]', '$_POST[opt3]', '$_POST[opt4]', '$_POST[ans]',$id);";
       if(mysqli_query($conn,$sql_a1))
   {
    ?>
    <script>
        document.querySelector('.alert-success').style.display="block";
        document.querySelector('.alert-warning').style.display="none";
        document.querySelector('#que').value="";
        document.querySelector('#opt1').value="";
        document.querySelector('#opt2').value="";
        document.querySelector('#opt3').value="";
        document.querySelector('#opt4').value="";
        document.querySelector('#ans').value="";
        </script>
    <?php
   }else
   {
    
    ?>  
    <script>
        
        document.querySelector('.alert-success').style.display="none";
        document.querySelector('.alert-warning').style.display="block";
        </script>
    <?php
   }
}
//    insert dat in database end
?>
<script>
    function Validation()
    {
        let x=document.querySelector('#time').value;
        let y=document.querySelector('#cat').value;
        if(y=="" || x=="")
        {
            document.querySelector('.alert-success').style.display="none";
            document.querySelector('.alert-warning').style.display="none";
            document.querySelector('.alert-danger').style.display="block";
            return false;
        }else{
            document.querySelector('.alert-success').style.display="none";
            document.querySelector('.alert-warning').style.display="none";
            document.querySelector('.alert-success').style.display="none";
            return true;
        }

        
    }
</script>

</body>
</html>
