

<?php

include '../connection.php';
include 'exam_category.php';
$id=$_GET["id"];
if($id!="")
    ?>
    <script>
        document.getElementById("dura").style.display="none";
        document.getElementById("update").style.display="block";
        </script>
    <?php
$sql="select * from exam_category where id=$id";
$res=mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($res))
{
$f=$row["category"];
$f1=$row["duration"];
    ?>
    <script>document.getElementById("cat").value="<?php echo $f;?>"
    document.getElementById("time").value="<?php echo $f1;?>"
   
</script>

    <?php
}
    if(isset($_POST["update"]))
    {
    $sql1="UPDATE exam_category SET category='$_POST[cat]',duration='$_POST[time]' where id=$id";
    if(mysqli_query($conn,$sql1))
    {
        header("location:exam_category.php");
        ?>
        <script>
            document.querySelector('.alert-primary').style.display="block";
            document.querySelector('#cat').value="";
            document.querySelector('#time').value="";
            setTimeout(() => {
                window.location="exam_category.php";
            }, 2000);
        </script>
        <?php
    }
    }


?>
