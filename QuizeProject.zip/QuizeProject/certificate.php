<?php
require 'pages/connection.php';
require 'fpdf/fpdf.php';
session_start();
$sql="select * from results where r_id=$_GET[result]";
$res=mysqli_query($conn,$sql);
$data=mysqli_fetch_array($res);
$sql1="select category from exam_category where id=$data[category_id]";
$res1=mysqli_query($conn,$sql1);
$data1=mysqli_fetch_array($res1);
$sql2="select Fname,Lname from register where user='$_SESSION[usrnm]'";
$res2=mysqli_query($conn,$sql2);
$data2=mysqli_fetch_array($res2);
header('content-type:image/jpeg');
$image=imagecreatefromjpeg("cert.jpg");
$color=imagecolorallocate($image,19,21,22);
$time=time();
$font='font.ttf';
$font1='Calita.otf';
$font3='arial.ttf';
$date=substr("$data[test_date]",3);
$date=$data["test_date"];
$id=$data["r_id"];
$name=$data2['Fname']." ".$data2['Lname'];
imagettftext($image,60,0,620,650,$color,$font3,"$name");
imagettftext($image,40,0,440,830,$color,$font3,"$data1[category]");
imagettftext($image,40,0,100,160,$color,$font3,"$date");
imagettftext($image,30,0,1740,200,$color,$font3,"S.N.$id");
imagejpeg($image,"downloadcert/time.jpeg");
imagedestroy($image);
$pdf=new FPDF;
$pdf->AddPage('L','A4');
$pdf->image("downloadcert/time.jpeg",0,0,300,210);
ob_end_clean();
$pdf->Output();

?>