<?php 

$conn=mysqli_connect("localhost:3306","root","");
mysqli_select_db($conn,"quiz");
if($conn->connect_error){   
    die("connection error");
}
// echo "connection successfully";
// if (!mysqli_select_db($conn, "quiz")) {
//     $error_message = "Failed to select database: " . mysqli_error($conn);
//     trigger_error($error_message, E_USER_ERROR);
// }echo "Connection and database selection successful.";

?>
