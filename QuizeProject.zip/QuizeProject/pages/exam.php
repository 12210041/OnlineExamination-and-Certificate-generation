<?php
require 'connection.php';
$sql="select * from exam_category where id=$_GET[eid]";
$res=mysqli_query($conn,$sql);
$data=mysqli_fetch_array($res);
session_start();
$std_id=$_SESSION['usrnm'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Document</title>
    <style>

       
        input{
            width:25px;
        }
        .head{
            background-color:green;
           display:grid;
           grid-template-columns:30% 30% 30%;
           position:sticky;
           width:100%;
           top:0;
        }
        
        .head p{
            font-size:30px;
            float:right;
            color:orange;
        }
        .footer{
            background-color:lightblue;
            position:fixed;
            bottom:0px;
            width:100%;
            height: 10vh;
            
        }
        
        .btn2{
            padding:20px;
            background-color:red;
            border-radius:20px;
            float:right;
            width:5%;
            cursor:pointer;
            margin:1%;
        }
        a{
            text-decoration:white;
        }
        .btn2 a{
            color:white;
            
        }
        .btn2:hover{
            background-color:green;
        }
        .body{
            width:80%;
            margin-left:10%;
            background-color:lightyellow;
            box-shadow:20px 10px 16px pink;
           margin-top:2%;
           border-radius:20px;
        }
        .status{
            display:flex;
            gap:2%;
            border-left:3px solid black;
            padding:2%;
        }
        .status a{
            background:green;
            padding:20px;
            color:white;
            font-size:20px;
            border-radius:10px;
        }
        .question{
            display:flex;
            gap:2%;
            border-left:3px solid black;
            padding:2%;
        }
        .question a{
            border:1px solid black;
            padding:10px;
            border-radius:10px;
        }
        /* .leftside{
            overflow:scroll;
            position:relative;
            top:100px;
            height:75vh;
        } */
        .rightside{
            overflow:scroll;
            width:85%;
            margin-left:15%;
            height:70vh;
    
        }
        ::-webkit-scrollbar {
  width: 20px;
}

/* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius: 10px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: lightblue; 
  border-radius: 10px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #b30000; 
}


            .permission{
                box-shadow:5px 7px 7px red;
                background:white;
                width:30%;
                margin-left:10%;
                transition:2s;
                position: absolute;
                top:27%;
                border-radius:30px;
                padding:10px;
                text-align:center;
                display:none;
            }

            .permission button{
                padding:10px;
                font-size:20px;
                color:red;
                border-radius:20px;
                background:lightgreen;
                float:right;
                
            }
            .permission button:hover{
                background:gray;
                color:white;
                cursor:pointer;
            }
    </style>
</head>
<body>
    <header class="head">
        <div>
            <p>Instruction</p>
        </div>
        <div>
            <p>Test Name: <span style="color:white;"><?php echo $data['category']; ?></span></p>
        </div>
        <div>
            <p>Remaining Time: <span id="timer" style='color:white;'><?php echo $data['duration'];?> </span>:<span id="sec" style='color:white;'></span>Seconds</p>
            
        </div>
    </header>
    <section class="body">
        <!-- <div class="leftside">
            <p>User Name:</p>
            <div class="status">
                <a>Attempted</a>
                <a>Flag</a>
                <a>Pending</a>
            </div>
            <p>Questions</p>
            <div class="question">
               
            </div> -->
        </div>
        <div class="rightside">
            <form style="font-size:30px;"  method="post">
            <?php
            $dques="select * from questions where category_id=$_GET[eid]";
            $result=mysqli_query($conn,$dques);
            $no_of_q=0;
            while($d=mysqli_fetch_array($result))
            {   $no_of_q=$no_of_q+1;
                echo "
                <p style='font-size:30px;'>$d[question]</p>
                <input type='radio' name='$d[q_id]' value='$d[opt1]' id='$d[q_id]$d[opt1]'><label for='$d[q_id]$d[opt1]'>$d[opt1]</label>
                <br>
                <input type='radio' name='$d[q_id]' value='$d[opt2]' id='$d[q_id]$d[opt2]'><label for='$d[q_id]$d[opt2]'>$d[opt2]</label>
                <br>
                <input type='radio' name='$d[q_id]' value='$d[opt3]' id='$d[q_id]$d[opt3]'><label for='$d[q_id]$d[opt3]'>$d[opt3]</label>
                <br>
                <input type='radio' name='$d[q_id]' value='$d[opt4]' id='$d[q_id]$d[opt4]'><label for='$d[q_id]$d[opt4]'>$d[opt4]</label>
                ";
            }
            
            ?>
                <div class="permission">
                    <span style="color:red;font-size:60px;text-align:center;padding:1px;"><i class="fa-solid fa-circle-exclamation"></i></span>
                    <p style="color:Black;font-size:30px;text-align:center;padding:1px;">Do You Want to Submit</p>
                    <button type="submit" name='submit' >yes</button>
                    <button type="button" onclick="cancel()">Cancel</button>
            </div>
            </form>
        </div>
    </section>
    <footer class="footer">
          <a onclick="endtest()" id="end" class="btn2">
          End Test</a>
    </footer>
                <?php
                 $count=0;
                 $attempt=0;
                if(isset($_POST['submit'])){
                    $sql="select * from questions where category_id=$_GET[eid]";
                        $res=mysqli_query($conn,$sql);
                      
                        while($data=mysqli_fetch_array($res))
                        {
                            $t=$_POST[$data['q_id']];
                            $p=$data['ans'];
                            
                        if($t==$p){
                            $count=$count+1;
                            $attempt=$attempt+1;
                            
                        } else if($t!=null)
                        {
                            $attempt=$attempt+1;
                        }
                        }

                $qsave="insert into results(category_id,no_of_q,attempted,marks,std_id) values($_GET[eid],$no_of_q,$attempt,$count,'$std_id');";
                if(mysqli_query($conn,$qsave))
                {
                   ?>
                   <script>
                    window.location="demo.php?eid=<?php echo $_GET['eid']?>";
                    </script>
                   <?php
                }else
                {
                    ?>
                    <script>
                            alert("Something went wrong!");
                        </script>
                    <?php
                }
                
                }
                ?>

        <script>
            function endtest()
            {
                document.querySelector('.permission').style.display="block";
            }
            function cancel()
            {
                document.querySelector('.permission').style.display="none";
            }
        </script>
</body>
</html>