<?php include 'connection.php';?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            background-image: url('/QuizeProject/img/b4.jpg');
        }
        .box {
            display: grid;
            grid-template-columns: 100%;
            border-radius: 20px;
            width: 25%;
            position: fixed;
            top: 10%;
            left: 37%; 
            box-shadow: 10px 10px 20px rgb(113, 174, 223);
            background-color: aliceblue;
        }
        input {
            width: 80%;
            padding: 5px;
            margin-left: 10%;
            border-radius: 20px;
        }
        label {
            margin-left: 10%;
            padding-top: 2%;
        }
        .footer {
            bottom:0px;
            position: fixed;
            height:6vh;
        }

       .header{
        height:9vh;
       }
        @media (max-width:900px) {
            .box {

                width: 80%;
                left: 10%;
                top:5%;
            }
            .footer{
                height:4vh;
            }
            .header{
            height:5vh;
             }
        }
        @media (max-width:400px) {
            .box {

                width: 80%;
                left: 10%;
                top:5%;
            }
            .footer{
                height:4vh;
            }
            .header{
            height:5vh;
             }
             label{
                padding:0;
             }
        }
        @media (min-height:750px) {
            .box {
                top:15%;
            }
            .footer{
                height:4vh;
            }
            .header{
            height:5vh;
             }
             label{
                padding:0;
             }
        }
        .btn {
            padding: 10px;
            width: 30%;
            font-size: 20px;
            margin: 10px;
        }
        input:focus {
            box-shadow: 2px 2px 5px green;
        }   
    </style>
</head>

<body>
 
    <div class="container-fluid bg-info header" >
        <h3 class="d-flex justify-content-center">Online Quiz Portal</h3>
    </div>
    <div class="register">
        <div class="box">
        <form  method="POST" name="signup_form">
            <div class="bg-info d-flex justify-content-center">
                <p style="padding:6px;font-size:30px;color:rgb(206, 16, 16);">Register</p>
            </div>
           
            <div>
                <label for="fname">First Name</label>
            </div>
            <div>
                <input type="text" name="fname" id="fname">
            </div>
            <div>
                <label for="lname">Last Name</label>
            </div>
            <div>
                <input type="text" name="lname" id="lname">
            </div>
            <div>
                <label for="ruser">username</label>
            </div>
            <div>
                <input type="text" name="ruser" id="ruser">
            </div>
            <div>
                <label for="rpass">Password</label>
            </div>
            <div>
                <input type="password" name="rpass" id="rpass">
            </div>
            <div>
                <label for="email">Email Id</label>
            </div>
            <div>
                <input type="email" name="email" id="email">
            </div>
            <div>
                <label for="mob">Mobile Number</label>
            </div>
            <div>
                <input type="text" name="mob" id="mob">
            </div>
            <div>
                <input type="checkbox" name="check" id="check" style="width: auto;">
                All details are correct and valid!
                
            </div>
            <div class="d-flex justify-content-center">
                <a href="login.php" class="btn btn-outline-primary" id="log"><i class="fa-sharp fa-solid fa-arrow-left"></i>Login</a>
                <button type="submit" name="submit1" class="btn btn-outline-success" onclick="return checkVal()">Register</button>
            </div>
            <div class="alert alert-success" role="alert"  style="display:none" id="success">
                Your registratration successfully
            </div>
            <div class="alert alert-danger" role="alert" style="display:none" id="failed">
                Username already exist
            </div>
        </form>
        </div>
    </div>
    </div>
    <div class="container-fluid bg-info footer">
        <h3 class="d-flex justify-content-center"><i>&copy;Pandey Technology</i></h3>
    </div>
    <script src="/QuizeProject/js/script.js"></script>
    <script src="/QuizeProject/js/jquery.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
    <!-- <script>
        $(document).ready(function () {
            $('#signup').click(function () {
                $('.register').css({ "transform": "translateX(0%)" });
                $('#login').css({ "transform": "translateX(100%)" });
            })
            $('#log').click(function () {
                $('.register').css({ "transform": "translateX(-100%)" });
                $('#login').css({ "transform": "translateX(0%)", "transition": "1s" });
            })
            
        })
    </script> -->

    <?php
   
if (isset($_POST["submit1"])) {
    $count = 0;
    $result = mysqli_query($conn, "SELECT * FROM register WHERE user = '$_POST[ruser]'");
    $count = mysqli_num_rows($result);
    if ($count > 0) {
        ?>
        <script type="text/javascript">
            document.querySelector('#failed').style.display = "block";
            document.querySelector('#success').style.display = "none";
            

        </script>
        
        <?php
        
    } else {
        date_default_timezone_set("Asia/Kolkata");
         $date=date('Y-m-d H:i:s');
        $sql= "INSERT INTO register(Fname,Lname,user,pass,email,mobile,datetime1) VALUES('$_POST[fname]','$_POST[lname]','$_POST[ruser]','$_POST[rpass]','$_POST[email]','$_POST[mob]','$date')";
        if (mysqli_query($conn, $sql)) {
            ?>
        <script type="text/javascript">
            document.querySelector('#success').style.display = "block";
            document.querySelector('#failed').style.display = "none";
        </script>
        <?php
        } else {
            echo "Error: " . mysqli_error($conn);
        }       
    }   
}
?>
<script>
    function checkVal(){
        var fname=document.getElementById('fname').value;
        var lname=document.querySelector('#lname').value;
        var usr=document.querySelector('#ruser').value;
        var pass=document.querySelector('#rpass').value;
        var email=document.querySelector('#email').value;
        var mob=document.querySelector('#mob').value;
        if(fname==""||lname==""||usr==""||pass==""||email==""||mob=="")
        {
            alert("All fields are required");
            return false;
        }
        else
        {
           if(pass<5)
           {
            alert("password Should be more than 5 Character");
            return false;
           }else
           {
            return true;
           }
        }
        
    }
</script>
    
</body>

</html>