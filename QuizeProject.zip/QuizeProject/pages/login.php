<?php session_start();
include 'connection.php';?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            background-image: url('/QuizeProject/img/b4.jpg');
        }

        .box {
            display: grid;
            grid-template-columns: 100%;
            border-radius: 20px;
            width: 25%;
            position: fixed;
            top: 18%;
            left: 37%;
            box-shadow: 10px 10px 20px rgb(113, 174, 223);
            background-color: aliceblue;
        }
        input,select{
            width: 80%;
            padding: 5px;
            margin-left: 10%;
            border-radius: 20px;
          
        }

        label {
            margin-left: 10%;
            padding-top: 2%;
        }

        @media (max-width:900px) {
            .box {

                width: 80%;
                top: 18%;
                left: 10%;
            }
        }

        .btn {
            padding: 10px;
            width: 30%;
            font-size: 20px;
            margin: 40px;
        }

        input:focus {
            box-shadow: 2px 2px 5px green;
        }
        select:focus {
            box-shadow: 2px 2px 5px green;
        }

        .footer {
            bottom: 0px;
            position: fixed;
        }
        .captae{
            width: 30%;
            margin-top:4%;
            border:none;
            background-image:url('https://as2.ftcdn.net/v2/jpg/02/52/10/67/500_F_252106794_NFwH5UYrzwwZpEov09qXDMQgJGCSzeiC.jpg');
            background-size:cover;
            font-size:30px;
            padding:0px;
            text-align:center;
            color:black;
            text-shadow:5px 5px 10px red;
            font-style: italic;
            font-weight: 300;
            letter-spacing: 3px;
            text-decoration: line-through;
        }
        #capalert{
            display:none;
            color:red;
        }
        .selectusr::after{
            content:'*';
            color:red;
        }
    </style>
</head>

<body>
    <div class="container-fluid bg-info" style="height: 10vh;">
        <h3 class="d-flex justify-content-center" style="padding: 20px;">Online Quiz Portal</h3>
    </div>
    <div class="bg-light" id="login">
        <div class="box">
            <form  method="POST" id="login_form" onsubmit="return captaValidation()">
                <div class="bg-info d-flex justify-content-center">
                    <p>Login</p>
                </div>
                <div>
                    <label for="selectuser" class="selectusr" >Select User</label>
                </div>
                <div >
                    <select name="selectuser" class="sltusr" style="text-align:center" onchange="selectUser()" id="sltusr">
                        <option value="select">-select user-</option>
                        <option value="admin">Admin</option>
                        <option value="student">Student</option>
                    </select>
                    
                </div>  
                <div>
                    <label for="username" id="a">username</label>
                </div>
                <div>
                    <input type="text" name="username" id="username" placeholder="example@xyz.com">
                </div>
                <div>
                    <label for="password">Password</label>
                </div>
                <div>
                    <input type="password" name="pass" id="pass">
                </div>
                
                <div class="d-flex">
                    <input type="text" name="capta" id="capta" class="captae"
                        value="<?php echo getCapta(5)?>" readonly >
                    <a href="#" onclick="RefreshCapta()" style="margin-top: 4%;font-size: 30px;"><i class="fa-solid fa-arrows-rotate"></i></a>
                    <input type="text" name="ecapta" id="ecapta" style="width:30%;margin-top:4%;margin-left:1%;" onkeypress="removeal()">
                </div>
                <div id="capalert">
                <p>Please enter valid capta</p>
                </div>
                <div class="d-flex justify-content-center">
                    <a href="signup.php" class="btn btn-outline-primary" id="signup" onclick="">Sign Up</a>
                    <button type="submit" name="loginsubmit" class="btn btn-outline-success">Login</button>
                </div>
                <div class="d-flex justify-content-end">
                    <a href="#" style="margin-bottom: 20px;padding:10px">Forget Passsword</a>
                </div>
            </form>
        </div>
    </div>
    <div class="container-fluid bg-info footer" style="height: 10vh;">
        <h3 class="d-flex justify-content-center" style="padding: 20px;"><i>&copy;Pandey Technology</i></h3>
    </div>
    <script src="/QuizeProject/js/script.js"></script>
    <script src="/QuizeProject/js/jquery.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
    <!-- <script>
        $(document).ready(function () {
            $('#signup').click(function () {
                $('.register').css({ "transform": "translateX(0%)" });
                $('#login').css({ "transform": "translateX(100%)" });
            })
            $('#log').click(function () {
                $('.register').css({ "transform": "translateX(-100%)" });
                $('#login').css({ "transform": "translateX(0%)", "transition": "1s" });
            })
        })
    </script> -->
   <!-- generate random string start-->
  
<?php
function getCapta($n) {
    $characters = '0123456789@!abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }
    return $randomString;
}
?>
<script>   
function RefreshCapta()
{
    let xx="<?php echo getCapta(5);?>";
    document.getElementById('capta').value=xx;
}
</script>
   <!-- generate random string end-->
   <!-- login data fetch start -->
   <?php
    if(isset($_POST["loginsubmit"]))
    {
      
      $get_type=$_POST['selectuser'];
      if($get_type=="student")
      {
            $count=0;
            $url="select pass from register where user='$_POST[username]' && pass='$_POST[pass]'";
            $res=mysqli_query($conn,$url);
            $count=mysqli_num_rows($res);
            if($count>0)
            {
                $_SESSION["usrnm"]=$_POST["username"];
                ?>
                <script>
                    
                    window.location="/QuizeProject/index.php";
                </script>
                <?php
            }else
            {
                ?>
                <script>
                    alert("invalid userid");
                </script>
                <?php 
            }
        }
        else if($get_type=="admin")
        {
            $admin=0;
            $url="select pass from admin where username='$_POST[username]' && pass='$_POST[pass]'";
            $res=mysqli_query($conn,$url);
            $admin=mysqli_num_rows($res);
            if($admin>0)
            {
                $_SESSION["adminu"]=$_POST["username"];
                ?>
                <script>
                    window.location="../admin";
                    </script>
                <?php
              
            }else
            {
                ?>
                <script>
                    alert("invalid password");
                    </script>
                <?php
            }
            
        }
        else if($get_type=="select"){
            ?>
            <script>
                alert("please select user!");
                </script>
            <?php
        }
        
    }
   ?>
   <script>
    
    function captaValidation()
    {
        let x=document.getElementById('capta').value;
        let y=document.getElementById('ecapta').value;
        if(x==y)
        {
            return true;
        }else
        {
            document.querySelector('#capalert').style.display="block";
            return false;
        }
    }
    function removeal(){
        document.querySelector('#capalert').style.display="none";
    }
    function selectUser()
    {
        let e=document.querySelector('#sltusr');
        let u=e.options[e.selectedIndex].value;
      
        if(u=="select")
        {
            document.querySelector('.sltusr').style.background="red";
        }else
        if(u=="admin")
        {
        document.querySelector('.sltusr').style.background="yellow";
        }
        else
        {
          document.querySelector('.sltusr').style.background="green";
        }

    }
    </script>
    <!-- login data fetch end -->
</body>

</html>