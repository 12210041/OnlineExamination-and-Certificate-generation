<?php
include 'header.php';
include 'connection.php';
$eid=$_GET['eid'];
$sql="select * from exam_category where id=$eid";
$res=mysqli_query($conn,$sql);
$total=mysqli_num_rows($res);
$data=mysqli_fetch_assoc($res);

?>

<body>
    <div class="container bg-light" style="margin-top:100px;">
    <div class="row">
        <div class="col-6">
            <h1>Test Details</h1>
          <table>
            <tr>
                <td>Test Name</td>
                <td> : <?php echo $data['category'];?></td>
            </tr>
            <tr>
                <td>Time Allocated in Minuts</td>
                <td> : <?php echo $data['duration'];?></td>
            </tr>
            <tr>
                <td>No of Question</td>
                <td> : <?php echo $total; ?></td>
            </tr>
            <tr>
                <td>Negative Marking</td>
                <td> : NaN</td>
            </tr>
        </table>
        </div>
        <div class="col-6">
            <h1>Test Instruction</h1>
            <ul>
                <li>This test is designed to check your competency in all the sections.</li>
                <li>You are advised to conduct the test with complete seriousness and environment simulated to match the actual test conditions.</li>
                <li>You can quit the test at any time by pressing Quit Test button (Available in the Review Screen) & take it later. While quitting the test you will get the option to start the test afresh or resume it from saved attempt.</li>
                <li>Press the Quit Test button once you have finished taking the test. Once submitted you cannot retake this test.</li>
                <li>On completion of the test, you can view the Score Card.</li>
            </ul>
            
        </div>
    </div>
    <form action="" align="center">
        
                <input type="checkbox" id="check" name="check" value="jj" required>
                I have gone through the instructions, understood legends and will hereby follow the same.
            </form>
    <a href="/quizeproject/index.php" class="btn btn-info" >Back</a>
    <a  class="btn btn-info" style="float:right" onclick="startexam()">Start</a>
    </div>
    <script>
        function startexam()
        {
            var check=document.getElementById('check');
            if(check.checked)
            window.open("exam.php?eid=<?php echo $eid?>", "", "width:90,resizable=no");
            else
            alert("Please agree T&C");
            document.querySelector('form').style.color="red";
           
        }
    </script>
</body>