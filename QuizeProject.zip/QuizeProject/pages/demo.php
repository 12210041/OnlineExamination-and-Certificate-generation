<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Document</title>
    <style>
        .mess{
            font-size:30px;
            overflow:hidden;
            justify-content:center;
            padding:10px;
        }
        i{
            color:green;
        }
    </style>
</head>
<body>
    <div class="mess">
        <p><i class="fa fa-check"></i> Thankyou for submited your exam</p>
        <form action="" method="post">
            <textarea name="feedback" id="" cols="20" rows="4" placeholder="write your suggestion here"></textarea>
            <a  onclick="first()"><i class="fa-solid fa-star" id="1"></i></a>
            <a onclick="secound()"><i class="fa-solid fa-star" id="2"></i></a>
            <a onclick="third()"><i class="fa-solid fa-star"  id="3"></i></a>
            <a onclick="fourth()"><i class="fa-solid fa-star" id="4"></i></a>
            <a onclick="fifth()"><i class="fa-solid fa-star"  id="5"></i></a>
            <button type="submit" name='submit'>Submit</button>
        </form>

    </div>
   
    <?php
    $star=0;
    ?>
    <script>
        var star=0;
        function first()
        {
           document.getElementById('1').style.color="#f3d512";
           document.getElementById('2').style.color="black";
           document.getElementById('3').style.color="black";
           document.getElementById('4').style.color="black";
           document.getElementById('5').style.color="black";
          
           <?php
           $star=1;
           ?>
        }
        function fifth()
        {
           document.getElementById('1').style.color="#f3d512";
           document.getElementById('2').style.color="#f3d512";
           document.getElementById('3').style.color="#f3d512";
           document.getElementById('4').style.color="#f3d512";
           document.getElementById('5').style.color="#f3d512";
           
           <?php
           $star=5;
           ?>
        }
        function secound()
        {
           document.getElementById('1').style.color="#f3d512";
           document.getElementById('2').style.color="#f3d512";
           document.getElementById('3').style.color="black";
           document.getElementById('4').style.color="black";
           document.getElementById('5').style.color="black";
         
           <?php
             $star=2;
           ?>
        }
        function third()
        {
           document.getElementById('1').style.color="#f3d512";
           document.getElementById('2').style.color="#f3d512";
           document.getElementById('3').style.color="#f3d512";
           document.getElementById('4').style.color="black";
           document.getElementById('5').style.color="black";
           
           <?php
           $star=3;
           ?>
        }
        function fourth()
        {
           document.getElementById('1').style.color="#f3d512";
           document.getElementById('2').style.color="#f3d512";
           document.getElementById('3').style.color="#f3d512";
           document.getElementById('4').style.color="#f3d512";
           document.getElementById('5').style.color="black";
           
           <?php
           $star=4;
           ?>
        }
    </script>
    <?php
    session_start();
    include 'connection.php';
    if(isset($_POST['submit']))
    {
      $sql="insert into rating(username,category_id,sugges,star) values('$_SESSION[usrnm]',$_GET[eid],'$_POST[feedback]',$star)";
      if(mysqli_query($conn,$sql))
      {
        echo "success";
        ?>
        <script>
            alert("Thankyou for sharing your response");
             window.opener = self;
            window.close();
        </script>
        <?php
      } else
      {
        echo "failure";
      }
    }
    ?>
</body>
</html>