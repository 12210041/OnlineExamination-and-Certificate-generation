-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 13, 2023 at 04:28 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `name` varchar(30) NOT NULL,
  `username` varchar(15) NOT NULL,
  `pass` int(10) NOT NULL,
  `email` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `username`, `pass`, `email`) VALUES
('suraj kumar pandey', 'skp3887', 123, 'psuraj470@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `exam_category`
--

CREATE TABLE `exam_category` (
  `id` int(5) NOT NULL,
  `category` varchar(100) NOT NULL,
  `duration` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam_category`
--

INSERT INTO `exam_category` (`id`, `category`, `duration`) VALUES
(111, 'PHP Basics', '30'),
(112, 'IT Basics', '30');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `q_id` int(11) NOT NULL,
  `question` varchar(500) NOT NULL,
  `opt1` varchar(500) NOT NULL,
  `opt2` varchar(500) NOT NULL,
  `opt3` varchar(500) DEFAULT NULL,
  `opt4` varchar(500) DEFAULT NULL,
  `ans` varchar(500) NOT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`q_id`, `question`, `opt1`, `opt2`, `opt3`, `opt4`, `ans`, `category_id`) VALUES
(27, 'PHP is an acronym for ____.', 'Prefix Hypertext Preprocessor', 'Prototype Hypertext Preprocessor', 'Hypertext Preprocessor', 'PHP: Hypertext Preprocessor', 'PHP: Hypertext Preprocessor', 111),
(28, 'Which is/are statement(s) true about PHP?', 'It is an open-source scripting language', 'PHP scripts execute on the server', 'It is used for developing dynamic & interactive websites', 'All of the above', 'All of the above', 111),
(29, 'What is the extension of a PHP file?', '.php', '.ph', '.phpfile', 'all of above', '.php', 111),
(30, 'Who developed PHP?', 'Guido van Rossum', 'Rasmus Lerdorf', 'Jesse James Garrett', 'Douglas Crockford', 'Rasmus Lerdorf', 111),
(31, 'In which year PHP was developed?', '1993', '1994', '1995', '1996', '1994', 111),
(32, 'A PHP script starts with ____ and ends with ___.', '<?php and ?>', '<php> and </php>', '<?php and /?php>', '</php and />', '<?php and ?>', 32),
(33, 'PHP keywords are case-sensitive?', 'Yes', 'No', '', '', 'No', 111),
(34, 'Single line comments can be placed in PHP script by using which symbol?', '//', '#', '$', 'both', 'both', 111),
(35, 'Multi-line comments can be written within the ____.', '// and //', '## and ##', '/* and */', '/// and ///', '/* and */', 111),
(36, 'A process is a _______.', 'single thread of execution.', 'program in the execution', 'program in the memory', 'task', 'program in the execution', 112),
(37, '2) The word processing feature that catches most random typographical errors and misspellings is known as _____.', 'Grammar checker', 'Spell checker', 'Word checker', 'None of the these', 'Spell checker', 112),
(38, 'What is smallest unit of the information?', 'A bit', 'A byte', 'A block', 'A nibble', 'A bit', 112),
(39, 'What is the decimal equivalent of the binary number 10111?', '21', '39', '42', '23', '23', 112),
(40, '5) What is the term for a temporary storage area that compensates for differences in data rate and data flow between devices?', 'Buffer', 'Bus', 'Channel', 'All of the above', 'Buffer', 112),
(41, ' How many color dots make up one color pixel on a screen?', '265', '3', '18', '6', '3', 112),
(42, 'Which of the following values is the correct value of this hexadecimal code 1F.01B?', '31.0065918', '31.0065917', '31.0065919', '31.0065915', '31.0065918', 112),
(43, 'How is the data stored on the diskette?', 'Magnetism', 'Ink', 'Laser bubbles', 'None of the these', 'Magnetism', 112),
(44, 'Which of the following is the smallest visual element on a video monitor?', 'Character', 'Pixel', 'Byte', 'Bit', 'Pixel', 112),
(45, ' Which of the following natural element is the primary element in computer chips?', 'Silicon', 'Carbon', 'Iron', 'Urenium', 'Silicon', 112),
(46, 'Which of the following programs enables you to calculate numbers related to rows and columns?', 'Window program', 'Spreadsheet program', 'Graphics program', 'Word program', 'Spreadsheet program', 112),
(47, ' Which of the following is a structured programming technique that graphically represents the detailed steps required to solve a program?', 'Object-oriented programming', 'Pseudocode', 'Flowchart', 'Top-down design', 'Flowchart', 112),
(48, 'Which of the following values is the correct value of this hexadecimal code ABCDEF?', '11259375', '11259379', '11259312', '11257593', '11259375', 112),
(49, 'Which of the following is an output device?', 'Keyboard', 'Mouse', 'ALU', 'VDU', 'VDU', 112),
(50, 'Which of the following is the extension of Notepad?', '.txt', '.xls', '.ppt', '.png', '.txt', 112),
(51, 'BIOS is used?', 'By operating system', 'By compiler', 'By interpreter', 'By application software', 'By operating system', 112),
(52, 'What is the mean of the Booting in the system?', 'Restarting computer', 'install the program', 'To scan', 'To turn off', 'Restarting computer', 112),
(53, 'A computer is accurate, but if the result of a computation is false, what is the main reason for it?', 'Power failure', 'The computer circuits', 'Distraction', 'Incorrect data entry', 'Incorrect data entry', 112),
(54, 'The central processing unit is located in the _____.', 'Hard disk', 'System unit', 'Memory unit', 'All of the above', 'System unit', 112),
(55, 'Which one of the following groups contains graphical file extensions?', 'JPG, CPX, GCM', 'GIF, TCE, WMF', 'TCP, JPG, BMP', 'JPG, GIF, BMP', 'JPG, GIF, BMP', 112),
(56, 'Which of the following is equal to a gigabyte?', '1024 bytes', '512 GB', '1024 megabytes', '1024 bits', '1024 megabytes', 112),
(57, 'How many bytes does 4 kilobytes represent?', '512', '1024', '4096', '8192', '4096', 112),
(58, 'Which type of program acts as an intermediary between a user of a computer and the computer hardware?', 'Operating system', 'User thread', 'Superuser thread', 'Application program', 'Operating system', 112),
(59, 'What kind of language can computer understand?', 'Normal language', 'Computer language', 'Assembly language', 'High-level language', 'Assembly language', 112),
(60, ' Which of the following values is the correct value of this binary code 1011 and 1111?', '11 and 14', '12 and 15', '11 and 15', '12 and 14', '11 and 15', 112),
(61, 'Which of the following is not one of the internal components of a CPU?', 'Control sequencer', 'M-D-R', 'M-A-R', 'Floppy disk', 'Floppy disk', 112),
(62, 'What is the speed of computer measured in?', 'Nanoseconds', 'Kilo-seconds', 'Gigahertz', 'Megabytes', 'Gigahertz', 112),
(63, 'What is the full form of RAM?', 'Remote Access Memory', 'Random Access Memory', 'Remote Access Memory', 'Random Access Memory', 'Random Access Memory', 112),
(64, 'What is the full form of DRAM?', 'Dynamic Remote Access Memory', 'Dynamic Random-Access Memory', 'Dependent Remote Access Memory', 'Dependent Random-Access Memory', 'Dynamic Random-Access Memory', 112);

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `rating_id` int(6) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `category_id` int(5) DEFAULT NULL,
  `sugges` varchar(300) DEFAULT NULL,
  `star` int(11) DEFAULT NULL,
  `rating_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`rating_id`, `username`, `category_id`, `sugges`, `star`, `rating_date`) VALUES
(11, 'pandey9931', 67, '', 4, '2023-11-12 11:25:10'),
(12, 'pandey9931', 67, '', 4, '2023-11-12 11:26:10'),
(13, 'pandey9931', 109, '', 4, '2023-11-12 11:28:51'),
(14, 'pandey9931', 109, '', 4, '2023-11-12 11:56:34'),
(15, 'pandey9931', 109, 'hgh', 4, '2023-11-12 11:56:59'),
(16, 'pandey9931', 109, '', 4, '2023-11-12 11:57:54'),
(17, 'pandey9931', 108, '', 4, '2023-11-12 12:05:16'),
(18, 'pandey9931', 108, '', 4, '2023-11-12 12:38:01'),
(19, 'pandey9931', 67, '', 4, '2023-11-12 12:38:42'),
(20, 'pandey9931', 67, '', 4, '2023-11-12 12:44:15'),
(21, 'pandey9931', 108, '', 4, '2023-11-13 11:22:51'),
(22, 'pandey9931', 111, '', 4, '2023-11-13 19:12:08'),
(23, 'pandey9931', 112, 'no', 4, '2023-11-13 20:18:24');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `s_id` int(5) NOT NULL,
  `Fname` varchar(15) NOT NULL,
  `Lname` varchar(10) DEFAULT NULL,
  `user` varchar(20) NOT NULL,
  `pass` varchar(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `datetime1` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`s_id`, `Fname`, `Lname`, `user`, `pass`, `email`, `mobile`, `datetime1`) VALUES
(11, '', '', 'admin', '123', '', '', '2023-11-13 20:29:31'),
(12, 'SURAJ', 'KUMAR', 'admine', '123', 'psuraj470@hotmail.com', '08507097130', '2023-11-13 20:38:14'),
(4, 'Anjali', 'Kumari', 'ajnali123', '123', 'anjalik@gmail.com', '898989898', '2023-10-02 17:51:07'),
(9, 'harsh', 'kumar', 'harsh', '123', 'psuraj470@hotmail.com', '8967676776', '2023-11-01 11:27:15'),
(3, 'jhjhj', 'hjh', 'jhjh', 'jhj', 'jhjh@jhjj.bbn', '8989898989', '2023-10-02 14:09:43'),
(1, 'dfddf', 'ffdfd', 'pa9931', '123', 'psuraj470@hotmail.com', '9006195930', '2023-10-13 15:26:30'),
(2, 'SURAJ', 'KUMAR', 'pandey9931', 'Skp@3887', 'psuraj470@hotmail.com', '09006195930', NULL),
(7, 'SURAJ', 'KUMAR', 'pandey9931i', 'Skp@3887', 'psuraj470@hotmail.com', '09006195930', '2023-10-02 22:08:10'),
(8, 'SURAJj', 'KUMAR', 'pandey9931ii', 'Skp@3887', 'psuraj470@hotmail.com', '09006195930', '2023-10-05 18:44:44'),
(10, 'saurabh', 'singh', 'sskp', '123', 'skp@gmail.com', '8989988989', '2023-11-11 20:52:36'),
(5, 'sweta', 'dwiwedi', 'sweta', '123', 'sweta@pandey.com', '898989898', '2023-10-02 17:52:12'),
(6, 'SURAJ', 'KUMAR', 'sweta1', 'Skp@3887', 'psuraj470@hotmail.com', '09006195930', '2023-10-02 17:52:25');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `r_id` int(6) NOT NULL,
  `category_id` int(3) NOT NULL,
  `no_of_q` int(6) NOT NULL,
  `attempted` int(5) NOT NULL,
  `marks` int(5) NOT NULL,
  `std_id` varchar(20) NOT NULL,
  `test_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`r_id`, `category_id`, `no_of_q`, `attempted`, `marks`, `std_id`, `test_date`) VALUES
(69, 111, 8, 8, 7, 'pandey9931', '2023-11-13 19:12:06'),
(70, 112, 29, 7, 4, 'pandey9931', '2023-11-13 20:18:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exam_category`
--
ALTER TABLE `exam_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`q_id`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`rating_id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`user`),
  ADD UNIQUE KEY `1` (`s_id`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`r_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `exam_category`
--
ALTER TABLE `exam_category`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `q_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `rating_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `s_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `r_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
