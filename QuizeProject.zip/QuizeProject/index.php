<?php 
include 'pages/header.php';
include 'pages/connection.php';
session_start();
if(!isset($_SESSION["usrnm"]))
{
  ?>
  <script>
    window.location="\pages/login.php";
    </script>
  <?php
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welcome</title>
  <link rel="stylesheet" href="style/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <style>
          .thead{
            text-align: center;
            padding:15px;
            color:white;
            font-size:20px;
            }
            .tableh{
              background-color:gray;
            }
            tr:hover{
              background-color:lightblue;
            }
      </style>
  </head>
  <body>

<section class="middle">
<div class="count bg-light">
<p class="d-flex justify-content-end">count down</p>
</div>
<!-- content area  -->
<div class="container quiz">
    <div class="row">
        <div class="col-6">
          <p class="bg-danger thead"><i class="fa fa-light fa-notes-medical"> </i> Test Available</p>
          <table width="100%">
            <tr class="tableh">
              <td width="10%">S.No.</td>
              <td width="60%">S.No.</td>
              <td width="20%">Duration</td>
              <td width="10%">Select</td>
          </tr>
          <?php
            $sql="select * from exam_category";
            $res=mysqli_query($conn,$sql);
            $count=0;
            while($data=mysqli_fetch_assoc($res))
            { $count++;
              echo "
                  <tr>
                  <td width=10%>$count</td>
                  <td width=60%>$data[category]</td>
                  <td width=20%>$data[duration]</td>
                  <td width=10%><a href='/quizeproject/pages/testinstruction.php?eid=$data[id]'><i class='fa-solid fa-hand-pointer'></i></a></td>
                  </tr>
              ";
            }
          ?>
          </table>
        </div>
        <div class="col-6">
        <p class="bg-primary thead"><i class="fa-solid fa-square-check"></i> Attempted Test</p>
          
            <table width="100%">
            <tr>
              <td>S.No.</td>
              <td>Test Name</td>
              <td>Total Ques</td>
              <td>Attempted</td>
              <td>Correct</td>
              <td>Marks %</td>
              <td>Date</td>
            </tr>
            <?php
            $atempt="select * from results where std_id='$_SESSION[usrnm]'";
            $res4=mysqli_query($conn,$atempt);
            $cn=0;
            while($data=mysqli_fetch_assoc($res4))
            { $cn++;
              $m=round(($data["marks"]/$data["attempted"])*100,2);
              $sql5="select category from exam_category where id=$data[category_id]";
              $res5=mysqli_query($conn,$sql5);
              $data1=mysqli_fetch_array($res5);
              echo "
           
              <tr>
              <td>$cn</td>
              <td><a href='certificate.php?result=$data[r_id]' target='_blank'>$data1[category]</a></td>
              <td>$data[no_of_q]</td>
              <td>$data[attempted]</td>
              <td>$data[marks]</td>
              <td>$m</td>
              <td>$data[test_date]</td>
            </tr>
        
              ";
            }
            ?>
          </table>

        </div>
    </div>
</div>
</section>
  <?php include 'pages/footer.html';?>
  </body>
</html>